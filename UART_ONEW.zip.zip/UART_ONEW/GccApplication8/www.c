/*
 * GccApplication8.c
 *
 * Created: 18.11.2025 13:09:27
 * Author : Wikte
 */ 

#include <avr/io.h>


int dupa(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

