/*
 * \license SPDX-License-Identifier: MIT
 */

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include <string.h>
#define F_CPU 16000000UL
#include "usart.h"


#define BUFF_SIZE   25


int main(void)
{	
	//DDRC = 0xFF;
	int16_t temp_raw;
	//uart_set_FrameFormat(USART_8BIT_DATA|USART_1STOP_BIT|USART_NO_PARITY|USART_ASYNC_MODE); // default settings
	uart_init(BAUD_CALC(115200)); // 8n1 transmission is set as default
	
	stdout = &uart0_io; // attach uart stream to stdout & stdin
	stdin = &uart0_io; // uart0_in and uart0_out are only available if NO_USART_RX or NO_USART_TX is defined
	
	sei(); // enable interrupts, library wouldn't work without this
			
	printf("Uart set up correctly\n");

	//char buffer[BUFF_SIZE];
	//uart_gets(buffer, BUFF_SIZE); // read at most 24 bytes from buffer (CR,LF will not be cut)
	
	int a = 0;
	
	while(1)
	{	
			if(ds18b20_read_temp(&temp_raw))
			{
				float tempC = temp_raw / 16.0;
			//	tempC = roundf(tempC * 100.0f) / 100.0f;
				uart_putfloat(tempC);
				uart_puts("\r\n");
					
				}
				else
				{
					uart_puts("Cos nie pyklo");
					uart_puts("\r\n");
				}	
					
		_delay_ms(5000);
	}
}