#ifndef DS18B20_H_
#define DS18B20_H_

uint8_t ds18b20_read_temp(int16_t *temp);

#endif
