W putty ustwiamy COMx
i transfer jest ustawiony na 115200 bit/s